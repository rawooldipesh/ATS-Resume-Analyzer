from flask import Flask, render_template, request, jsonify
import os
from dotenv import load_dotenv
import google.generativeai as genai
from PyPDF2 import PdfReader

# Load environment variables and configure API
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-1.5-flash")

# Function to get Gemini output
def get_gemini_output(pdf_text, prompt):
    try:
        response = model.generate_content([pdf_text, prompt])
        return response.text
    except Exception as e:
        return f"Error generating content: {str(e)}"

# Function to read PDF
def read_pdf(uploaded_file):
    if uploaded_file is not None:
        try:
            pdf_reader = PdfReader(uploaded_file)
            pdf_text = ""
            for page in pdf_reader.pages:
                pdf_text += page.extract_text()
            return pdf_text
        except Exception as e:
            raise Exception(f"Error reading PDF file: {str(e)}")
    else:
        raise FileNotFoundError("No file uploaded")

# Initialize Flask app
app = Flask(__name__)

# Route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle file upload and resume analysis
@app.route('/analyze', methods=['POST'])
def analyze():
    if 'resume' not in request.files:
        return jsonify({'error': 'No resume uploaded'}), 400
    
    resume_file = request.files['resume']
    job_description = request.form.get('job_description', '')

    try:
        pdf_text = read_pdf(resume_file)
    except Exception as e:
        return jsonify({'error': str(e)}), 400

    analysis_option = request.form.get('analysis_option', 'Quick Scan')
    
    # Create the prompt based on the analysis option
    if analysis_option == "Quick Scan":
        prompt = f"""
        You are ResumeChecker, an expert in resume analysis. Provide a quick scan of the following resume:
        (dont give "*" this symbol in start and end and also dont give hashtag)
        1. Give an overall ATS score out of 100 as
           ATS SCORE:
        2. Identify the most suitable profession for this resume.
        3. List 3 key strengths of the resume.
        4. Suggest 2 quick improvements.
        
        
        Resume text: {pdf_text}
        Job description (if provided): {job_description}
        """
    elif analysis_option == "Detailed Analysis":
        prompt = f"""
        You are ResumeChecker, an expert in resume analysis. Provide a detailed analysis of the following resume:
        
        1. Identify the most suitable profession for this resume.
        2. List 5 strengths of the resume.
        3. Suggest 3-5 areas for improvement with specific recommendations.
        4. Rate the following aspects out of 10: Impact, Brevity, Style, Structure, Skills.
        5. Provide a brief review of each major section (e.g., Summary, Experience, Education).
        6. Give an overall ATS score out of 100 with a breakdown of the scoring.
        
        Resume text: {pdf_text}
        Job description (if provided): {job_description}
        """
    else:  # ATS Optimization
        prompt = f"""
        You are ResumeChecker, an expert in ATS optimization. Analyze the following resume and provide optimization suggestions:
        
        1. Identify keywords from the job description that should be included in the resume.
        2. Suggest reformatting or restructuring to improve ATS readability.
        3. Recommend changes to improve keyword density without keyword stuffing.
        4. Provide 3-5 bullet points on how to tailor this resume for the specific job description.
        5. Give an ATS compatibility score out of 100 and explain how to improve it.
        
        Resume text: {pdf_text}
        Job description: {job_description}
        """

    response = get_gemini_output(pdf_text, prompt)
    
    # Parse the response into a more structured format
    formatted_response = response.replace("\n", "<br>")  # Replace line breaks with HTML <br> tags
    
    # Return the analysis results in a user-friendly HTML format
    return jsonify({'analysis_result': formatted_response})


# # Route for feedback form (optional)
# @app.route('/feedback', methods=['POST'])
# def feedback():
#     user_feedback = request.form.get('feedback')
#     if user_feedback:
#         # Handle feedback (store it or send it to email)
#         return jsonify({'message': 'Thank you for your feedback!'}), 200
#     else:
#         return jsonify({'error': 'Feedback is empty'}), 400
    

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if request.method == 'POST':
        user_feedback = request.form.get('feedback')
        if user_feedback:
            return jsonify({'message': 'Thank you for your feedback!'}), 200
        else:
            return jsonify({'error': 'Feedback is empty'}), 400
    else:
        return "Feedback page - Please submit feedback via the form.", 200

if __name__ == '__main__':
    app.run(debug=True)